#include "view.hpp"

View::View(int height, int width)
        : mHeight(height), mWidth(width)
{
}